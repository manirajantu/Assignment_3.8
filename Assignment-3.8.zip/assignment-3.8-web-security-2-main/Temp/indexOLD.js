
// console.log(process.argv[0]);
// console.log(process.argv[1]);
console.log(process.argv[2]); // First argument after `node index.js`
console.log(process.argv[3]); // Second argument after `node index.js`